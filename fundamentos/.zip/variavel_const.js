var a= 3
let b= 5
const c= 7

console.log(a,b,c)
a=9
b=15
console.log(a,b,c)