const peso1= 1
const peso2= Number("2.0")

console.log(peso1,peso2)
console.log(Number.isInteger(peso1))

const ava1= 7.423
const ava2= 5.234
const res= ava1*peso1 + ava2*peso2
const notaf= res/3

console.log(res)
console.log(res.toFixed(1))
console.log(res.toString(2))
