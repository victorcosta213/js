console.log("olá,mundo!") // setenças de código
{
    console.log("vamos se bora!") // bloco de códigos
}