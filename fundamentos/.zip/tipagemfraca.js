let qualquer= "fraca"
console.log(qualquer)
console.log(typeof qualquer)

qualquer= 12.34
console.log(qualquer)
console.log(typeof qualquer)


